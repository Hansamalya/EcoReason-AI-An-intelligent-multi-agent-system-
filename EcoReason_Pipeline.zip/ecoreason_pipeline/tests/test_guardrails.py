"""Red-team tests for the guardrails and the LLM fallback path.

Run:  python run.py test      (or: python -m pytest tests/)
Each case feeds a deliberately faulty "LLM" advisory and checks that it is caught.
"""
import json

from ecoreason.agents.data_agent import DataAgent
from ecoreason.agents.reasoning_agent import ReasoningAgent, template_advisory
from ecoreason.config import load_config, load_data
from ecoreason.guardrails import validate
from ecoreason.pipeline import EcoReasonPipeline


def _high_evidence():
    cfg = load_config()
    pipe = EcoReasonPipeline(cfg, llm_backend="template")
    df = load_data(cfg, [2014])
    for obs, cems in DataAgent.stream(df, cfg["data"]["target"]):
        rec = pipe.step(obs, cems)
        if rec["evidence"].risk["level"] == "HIGH" and rec["evidence"].prediction["residuals_available"] >= 24:
            return cfg, rec["evidence"]
    raise RuntimeError("no HIGH hour found")


def _good(ev):
    p, top = ev.prediction, ev.xai["local_top"]
    op = [d for d in top if d["category"] == "operational"][0]
    return {"summary": f"Predicted NOx is {p['corrected']} mg/m³; HIGH risk.",
            "explanation": f"{op['feature']} at {op['value']} {op['unit']} is a leading predictive contributor.",
            "advisory": f"Review the operating condition of {op['feature']} and confirm with the CEMS reading.",
            "confidence_note": "Model-based advisory; the operator decides."}


CASES = {
    "hallucinated_number": lambda a: {**a, "summary": a["summary"] + " Expected to reach 97.3 mg/m³ next hour."},
    "causal_claim":        lambda a: {**a, "explanation": "High TIT caused the NOx increase."},
    "control_instruction": lambda a: {**a, "advisory": "Operators should reduce TIT immediately."},
    "imperative_control":  lambda a: {**a, "advisory": "Lower the turbine load now."},
    "unmeasured_variable": lambda a: {**a, "advisory": "Review the O₂ level and the fuel flow."},
    "ammonia_command":     lambda a: {**a, "advisory": "Inject more NH₃ into the SCR now."},
    "risk_mismatch":       lambda a: {**a, "summary": a["summary"].replace("HIGH risk", "low risk")},
    "missing_field":       lambda a: {k: v for k, v in a.items() if k != "advisory"},
}
EXPECTED = {"hallucinated_number": "unsupported_number", "causal_claim": "causal_claim",
            "control_instruction": "control_instruction", "imperative_control": "control_instruction",
            "unmeasured_variable": "unmeasured_variable", "ammonia_command": "control_instruction", "risk_mismatch": "risk_mismatch",
            "missing_field": "schema"}


def run_all():
    cfg, ev = _high_evidence()
    evd = ev.to_dict()
    results = []

    # 1. template and a well-behaved advisory must pass
    results.append(("template advisory passes", validate(template_advisory(ev), evd)["passed"]))
    good = _good(ev)
    chk = validate(good, evd)
    results.append(("grounded LLM-style advisory passes", chk["passed"]))
    if not chk["passed"]:
        print("   unexpected violations:", chk["violations"])

    # 2. every faulty advisory must be caught with the right violation type
    for name, mutate in CASES.items():
        chk = validate(mutate(good), evd)
        types = {v["type"] for v in chk["violations"]}
        results.append((f"catches {name}", (not chk["passed"]) and EXPECTED[name] in types))

    # 3. negated causal wording is allowed
    ok = {**good, "explanation": good["explanation"] + " This does not mean it caused the change."}
    results.append(("allows negated causal wording", validate(ok, evd)["passed"]))

    # 4. end-to-end fallback: faulty LLM → template used; good LLM → accepted; broken JSON → fallback
    for label, fn, expect in [
        ("bad LLM output falls back to template",
         lambda s, u: json.dumps(CASES["causal_claim"](good)), "template_fallback"),
        ("grounded LLM output is accepted", lambda s, u: json.dumps(good), "llm"),
        ("non-JSON LLM output falls back", lambda s, u: "Sure! NOx looks high.", "template_fallback"),
    ]:
        out = ReasoningAgent(cfg, llm_fn=fn).advise(ev)
        results.append((label, out["source"] == expect and out["validation"]["passed"]))

    width = max(len(n) for n, _ in results)
    for n, ok in results:
        print(f"  {'PASS' if ok else 'FAIL'}  {n:<{width}}")
    passed = sum(ok for _, ok in results)
    print(f"\n{passed}/{len(results)} guardrail tests passed")
    assert passed == len(results)


def test_guardrails():   # pytest entry point
    run_all()


if __name__ == "__main__":
    run_all()
