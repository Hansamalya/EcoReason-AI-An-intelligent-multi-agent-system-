"""EcoReason AI — multi-agent decision support for NOx emission monitoring."""
__version__ = "0.1.0"
