"""Safety & grounding checks applied to every advisory before it reaches the operator.

Implements the boundaries on slide 11:
- no hallucinated measurements (every number must come from the evidence package)
- no unsupported physical causality
- no direct control instructions
- no variables that the model does not measure
- risk level must match the evidence
- data-quality warnings must be passed on
If any check fails, the pipeline falls back to the deterministic template advisory.
"""
import re
from typing import Any

REQUIRED_FIELDS = ("summary", "explanation", "advisory")
MAX_CHARS = 1500

_NUM = re.compile(r"(?<![A-Za-z])-?\d+(?:\.\d+)?")
_CAUSAL = re.compile(
    r"\b(caus(?:e|ed|es|ing)|due to|because of|because|result(?:s|ed)? (?:of|from)|leads? to|led to|"
    r"responsible for|driven by|triggered by)\b", re.I)
_NEGATION = re.compile(r"\b(not|no|cannot|can't|does not|do not|doesn't|without)\b[^.]{0,40}$", re.I)
_CONTROL_MODAL = re.compile(
    r"\b(should|must|please|recommend(?:ed)?(?: to)?|need to|needs to|consider)\s+"
    r"(increas|decreas|reduc|rais|lower|adjust|chang|set|open|clos|shut|cut|trip|inject|throttl)\w*", re.I)
_CONTROL_IMPERATIVE = re.compile(
    r"(?:^|[.!;:]\s+|\n\s*[-•*]?\s*)(increase|decrease|reduce|raise|lower|adjust|change|set|open|close|"
    r"shut|cut|trip|inject|throttle)\b", re.I)
_UNMEASURED = re.compile(
    r"\b(SCR|ammonia|NH3|NH₃|urea|fuel flow|fuel rate|O2|O₂|oxygen|CO\b|carbon monoxide|"
    r"water injection|steam injection|burner)\b", re.I)
_NH3_WORDS = {"scr", "ammonia", "nh3", "nh₃"}
_RISK_WORD = re.compile(r"\b(low|medium|high)\s+(?:NO[xₓ]\s+)?risk\b|\brisk(?:\s+level)?\s+(?:is\s+|of\s+)?"
                        r"(low|medium|high)\b", re.I)
_CAVEAT = re.compile(r"\b(range|reliab\w*|quality|caution|uncertain\w*|confidence|outside|unusual)\b", re.I)


def _allowed_numbers(evidence: dict[str, Any]) -> set[float]:
    vals: set[float] = set(range(0, 11))

    def walk(o):
        if isinstance(o, bool):
            return
        if isinstance(o, (int, float)):
            vals.add(abs(float(o)))
        elif isinstance(o, str):
            for m in _NUM.findall(o):
                vals.add(abs(float(m)))
        elif isinstance(o, dict):
            for v in o.values():
                walk(v)
        elif isinstance(o, (list, tuple)):
            for v in o:
                walk(v)
    walk(evidence)
    return vals


def _number_ok(n: float, allowed: set[float]) -> bool:
    n = abs(n)
    return any(abs(n - a) <= 0.051 or (a and abs(n - a) / a <= 0.005) or abs(n - round(a)) < 1e-9
               for a in allowed)


def validate(advisory: dict[str, Any], evidence: dict[str, Any]) -> dict[str, Any]:
    """Return {'passed': bool, 'violations': [{'type', 'detail'}]}."""
    v: list[dict[str, str]] = []

    for f in REQUIRED_FIELDS:
        if not isinstance(advisory.get(f), str) or not advisory[f].strip():
            v.append({"type": "schema", "detail": f"missing field '{f}'"})
    text = "\n".join(str(advisory.get(f, "")) for f in ("summary", "explanation", "advisory", "confidence_note"))
    if len(text) > MAX_CHARS:
        v.append({"type": "too_long", "detail": f"{len(text)} characters"})

    allowed = _allowed_numbers(evidence)
    bad = sorted({m for m in _NUM.findall(text) if not _number_ok(float(m), allowed)}, key=float)
    for m in bad:
        v.append({"type": "unsupported_number", "detail": m})

    for m in _CAUSAL.finditer(text):
        before = text[max(0, m.start() - 60): m.start()]
        if not _NEGATION.search(before):
            v.append({"type": "causal_claim", "detail": text[max(0, m.start() - 30): m.end() + 30].strip()})

    for rx in (_CONTROL_MODAL, _CONTROL_IMPERATIVE):
        for m in rx.finditer(text):
            v.append({"type": "control_instruction", "detail": text[m.start(): m.end() + 30].strip()})

    has_nh3 = bool(evidence.get("ammonia"))
    for m in _UNMEASURED.finditer(text):
        if has_nh3 and m.group(0).lower() in _NH3_WORDS:
            continue          # allowed: the evidence package carries the NH3 estimate
        v.append({"type": "unmeasured_variable", "detail": m.group(0)})

    level = evidence.get("risk", {}).get("level", "")
    for m in _RISK_WORD.finditer(text):
        said = (m.group(1) or m.group(2)).upper()
        if said != level:
            v.append({"type": "risk_mismatch", "detail": f"text says {said}, evidence says {level}"})

    if evidence.get("data_quality", {}).get("status") == "WARNING" and not _CAVEAT.search(text):
        v.append({"type": "missing_data_caveat", "detail": "data-quality warning not passed on"})

    return {"passed": not v, "violations": v}
