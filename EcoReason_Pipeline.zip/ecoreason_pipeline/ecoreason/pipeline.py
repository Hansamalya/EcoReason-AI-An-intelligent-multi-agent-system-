"""Orchestrator: Observe → Predict → Reason → (operator) → CEMS feedback.

For each hour of the replay stream:
  1. Data Agent validates the inputs and updates the plant state
  2. Prediction Agent predicts NOx, applies ME correction, assigns risk, builds XAI evidence
  3. Reasoning Agent writes the advisory (LLM or template), checked by guardrails
  4. The CEMS value for that hour "arrives" and is fed back to the Prediction Agent
"""
import json
import time
from datetime import datetime
from pathlib import Path

import pandas as pd

from .agents.data_agent import DataAgent
from .agents.prediction_agent import PredictionAgent
from .agents.reasoning_agent import ReasoningAgent
from .config import load_data, resolve


class EcoReasonPipeline:
    def __init__(self, cfg: dict, llm_backend: str | None = None, llm_fn=None):
        self.cfg = cfg
        if llm_backend:
            cfg["llm"]["backend"] = llm_backend
        art = resolve(cfg, cfg["artifacts_dir"])
        self.prediction_agent = PredictionAgent(art, cfg)
        meta = self.prediction_agent.meta
        da = cfg["data_agent"]
        self.data_agent = DataAgent(meta["features"], meta["feature_ranges"],
                                    da["range_margin"], da["history_hours"])
        self.reasoning_agent = ReasoningAgent(cfg, llm_fn=llm_fn)
        self.target = meta["target"]

    def step(self, obs: dict, cems_value: float | None) -> dict:
        """Process one observation end to end. Returns a log record."""
        t0 = time.perf_counter()
        state = self.data_agent.observe(obs)
        t1 = time.perf_counter()
        ev = self.prediction_agent.assess(state)
        t2 = time.perf_counter()
        adv = self.reasoning_agent.advise(ev)
        t3 = time.perf_counter()
        cems_status = self.prediction_agent.receive_measurement(ev.step_id, cems_value)  # arrives after advisory
        return {"evidence": ev, "advisory": adv, "cems": cems_value, "cems_status": cems_status,
                "timing": {"data_s": t1 - t0, "predict_s": t2 - t1, "reason_s": t3 - t2, "total_s": t3 - t0}}

    def run(self, df: pd.DataFrame | None = None, limit: int | None = None, start: int = 0,
            out_dir: Path | None = None, verbose: bool = False) -> Path:
        if df is None:
            df = load_data(self.cfg, [int(y) for y in self.cfg["data"]["replay_years"]])
        df = df.iloc[start: None if limit is None else start + limit]
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        out_dir = out_dir or resolve(self.cfg, self.cfg["output_dir"]) / f"run_{stamp}_{self.cfg['llm']['backend']}"
        out_dir.mkdir(parents=True, exist_ok=True)

        rows = []
        n = len(df)
        t_start = time.perf_counter()
        with open(out_dir / "evidence_log.jsonl", "w", encoding="utf-8") as log:
            for i, (obs, cems) in enumerate(DataAgent.stream(df, self.target)):
                rec = self.step(obs, cems)
                ev, adv = rec["evidence"], rec["advisory"]
                level = ev.risk["level"]
                rows.append({
                    "step_id": ev.step_id, "year": obs["YEAR"], "hour_idx": obs["HOUR_IDX"],
                    "cems_nox": cems, "cems_status": rec["cems_status"], "pred_raw": ev.prediction["raw"],
                    "me_correction": ev.prediction["me_correction"], "pred_corrected": ev.prediction["corrected"],
                    "nh3_mg_per_m3": ev.ammonia["nh3_mg_per_m3"] if ev.ammonia else None,
                    "risk_level": level, "trend": ev.risk["trend"], "escalated": ev.risk["escalated"],
                    "data_quality": ev.data_quality["status"], "n_flags": len(ev.data_quality["flags"]),
                    "top_feature": ev.xai["local_top"][0]["feature"] if ev.xai["local_top"] else None,
                    "advisory_source": adv["source"], "guardrail_passed": adv["validation"]["passed"],
                    "llm_violation_types": ";".join(sorted({v["type"] for v in adv["llm_violations"]})),
                    "llm_error": adv["llm_error"],
                    **{k: round(v * 1000, 3) for k, v in
                       {"data_ms": rec["timing"]["data_s"], "predict_ms": rec["timing"]["predict_s"],
                        "reason_ms": rec["timing"]["reason_s"], "total_ms": rec["timing"]["total_s"]}.items()},
                    "advisory_text": adv["advisory"]["advisory"],
                })
                if level != "LOW":   # full evidence + advisory for every alert hour
                    log.write(json.dumps({"evidence": ev.to_dict(), "advisory": adv, "cems_nox": cems},
                                         ensure_ascii=False, default=float) + "\n")
                if verbose and level in ("MEDIUM", "HIGH"):
                    print(f"[{level:6}] {adv['advisory']['summary']}  -> {adv['advisory']['advisory']}")
                if (i + 1) % 2000 == 0 or i + 1 == n:
                    el = time.perf_counter() - t_start
                    print(f"  processed {i + 1:,}/{n:,} observations ({el:.1f} s)")
        hourly = pd.DataFrame(rows)
        hourly.to_csv(out_dir / "hourly_results.csv", index=False)
        (out_dir / "run_info.json").write_text(json.dumps({
            "backend": self.cfg["llm"]["backend"], "observations": n, "start_index": start,
            "llm_calls": self.reasoning_agent.n_calls,
            "risk_thresholds": self.prediction_agent.thr,
            "risk_threshold_basis": self.prediction_agent.meta["risk_threshold_basis"],
            "me_window_hours": self.cfg["me_correction"]["window_hours"],
            "ammonia": self.cfg.get("ammonia")}, indent=2), encoding="utf-8")
        print(f"Run saved to {out_dir}")
        return out_dir
