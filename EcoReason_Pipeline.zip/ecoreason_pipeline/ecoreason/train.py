"""Stage 0 — train the NOx model and write the artifacts used by the agents.

Everything stored here is computed from the TRAINING years only, so the
replay of later years is a fair, unseen test.

Artifacts
- model.joblib          XGBoost model (fitted on scaled features)
- scaler.joblib         Min–Max scaler to [-1, 1]
- meta.json             features, ranges, risk thresholds, global importance, metrics
"""
import json
import time

import joblib
import numpy as np
from sklearn.inspection import permutation_importance
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.preprocessing import MinMaxScaler
from xgboost import XGBRegressor

from .config import load_data, resolve


def _metrics(y, p):
    return {
        "MAE": float(mean_absolute_error(y, p)),
        "RMSE": float(np.sqrt(mean_squared_error(y, p))),
        "R2": float(r2_score(y, p)),
        "ME": float(np.mean(y - p)),
    }


def train(cfg: dict, verbose: bool = True) -> dict:
    F, T = cfg["data"]["features"], cfg["data"]["target"]
    train_years = [int(y) for y in cfg["data"]["train_years"]]
    params = cfg["model"]["params"]
    art = resolve(cfg, cfg["artifacts_dir"])
    art.mkdir(parents=True, exist_ok=True)

    df = load_data(cfg, train_years)
    t0 = time.time()

    # --- 1. Global importance, computed out-of-sample on the last training year ---------
    #     (model trained on the earlier years, permuted on the last year)
    early, last = df[df.YEAR < max(train_years)], df[df.YEAR == max(train_years)]
    sc_e = MinMaxScaler(feature_range=(-1, 1)).fit(early[F])
    m_e = XGBRegressor(**params, n_jobs=-1).fit(sc_e.transform(early[F]), early[T])
    val_metrics = _metrics(last[T].values, m_e.predict(sc_e.transform(last[F])))
    perm = permutation_importance(m_e, sc_e.transform(last[F]), last[T].values, n_repeats=5,
                                  random_state=params.get("random_state", 0),
                                  scoring="neg_root_mean_squared_error")
    global_imp = sorted(
        [{"feature": f, "importance": round(float(v), 4)} for f, v in zip(F, perm.importances_mean)],
        key=lambda d: -d["importance"])
    for rank, d in enumerate(global_imp, 1):
        d["rank"] = rank

    # --- 2. Final model on all training years -------------------------------------------
    scaler = MinMaxScaler(feature_range=(-1, 1)).fit(df[F])
    model = XGBRegressor(**params, n_jobs=-1).fit(scaler.transform(df[F]), df[T])
    train_metrics = _metrics(df[T].values, model.predict(scaler.transform(df[F])))

    # --- 3. Risk thresholds and valid input ranges ----------------------------------------
    rc = cfg["risk"]
    if rc["mode"] == "percentile":
        thresholds = {"MEDIUM": float(np.percentile(df[T], rc["medium_percentile"])),
                      "HIGH": float(np.percentile(df[T], rc["high_percentile"]))}
        basis = (f"P{rc['medium_percentile']} / P{rc['high_percentile']} of training-period "
                 f"{T} ({min(train_years)}–{max(train_years)})")
    else:
        thresholds = {"MEDIUM": float(rc["absolute"]["medium"]), "HIGH": float(rc["absolute"]["high"])}
        basis = "absolute limits from config"
    ranges = {f: {"min": float(df[f].min()), "max": float(df[f].max())} for f in F}

    joblib.dump(model, art / "model.joblib")
    joblib.dump(scaler, art / "scaler.joblib")
    meta = {
        "model_type": cfg["model"]["type"], "params": params,
        "features": F, "target": T, "train_years": train_years,
        "feature_ranges": ranges,
        "risk_thresholds": {k: round(v, 2) for k, v in thresholds.items()},
        "risk_threshold_basis": basis,
        "global_importance": global_imp,
        "global_importance_basis": (f"permutation importance (ΔRMSE) on {max(train_years)}, "
                                    f"model trained on {min(train_years)}–{max(train_years) - 1}"),
        "validation_metrics_last_train_year": val_metrics,
        "train_metrics_in_sample": train_metrics,
        "train_seconds": round(time.time() - t0, 1),
    }
    (art / "meta.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
    if verbose:
        print(f"Trained on {len(df):,} rows ({min(train_years)}–{max(train_years)}) in {meta['train_seconds']} s")
        print(f"Validation on {max(train_years)}: RMSE {val_metrics['RMSE']:.2f}, R² {val_metrics['R2']:.3f}")
        print(f"Risk thresholds: MEDIUM ≥ {thresholds['MEDIUM']:.1f}, HIGH ≥ {thresholds['HIGH']:.1f} "
              f"{cfg['units'][T]}  ({basis})")
        print("Global importance:", ", ".join(d["feature"] for d in global_imp[:5]))
        print(f"Artifacts written to {art}")
    return meta
