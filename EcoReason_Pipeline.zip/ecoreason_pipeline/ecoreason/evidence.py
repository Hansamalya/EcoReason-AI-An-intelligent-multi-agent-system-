"""Structured objects passed between agents.

PlantState       produced by the Data Agent
EvidencePackage  produced by the Prediction Agent, consumed by the LLM Reasoning Agent
"""
from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass
class PlantState:
    step_id: str
    year: int
    hour_idx: int
    values: dict[str, float]                  # current input features
    quality: str                              # OK | WARNING | INVALID
    flags: list[str] = field(default_factory=list)
    history_len: int = 0

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class EvidencePackage:
    step_id: str
    plant_state: dict[str, Any]               # {feature: {"value", "unit", "description"}}
    data_quality: dict[str, Any]              # {"status", "flags"}
    prediction: dict[str, Any]                # raw, me_correction, corrected, unit, me_window_hours
    risk: dict[str, Any]                      # level, thresholds, trend, escalated, rule
    xai: dict[str, Any]                       # local contributors + global ranking
    recent_predictions: list[float]
    model: dict[str, Any]
    ammonia: dict[str, Any] | None = None     # indicative NH3 requirement (None if disabled)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    def llm_view(self) -> dict[str, Any]:
        """Compact version sent to the LLM (only what it is allowed to talk about)."""
        return {
            "step_id": self.step_id,
            "prediction": self.prediction,
            "risk": self.risk,
            "local_contributors": self.xai["local_top"],
            "global_top_features": self.xai["global_top"],
            "plant_state": self.plant_state,
            "data_quality": self.data_quality,
            "recent_corrected_predictions": self.recent_predictions,
            "ammonia_estimate": self.ammonia,
        }
