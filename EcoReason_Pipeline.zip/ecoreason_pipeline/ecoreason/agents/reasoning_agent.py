"""Agent 3 — LLM Reasoning Agent.

Turns the Evidence Package into a short, grounded, conservative advisory.

Backends
- template   deterministic rule-based text (offline baseline, also the safety fallback)
- anthropic  Claude via the Anthropic Messages API (needs ANTHROPIC_API_KEY)
- ollama     any local open model served by Ollama (free, runs on your laptop)

Every LLM output is checked by `guardrails.validate`. If it fails, or the LLM call
errors, the template advisory is used instead and the violation is logged.
"""
import json
import os
import re
import time
from typing import Any, Callable

import requests

from .. import guardrails
from ..evidence import EvidencePackage

SYSTEM_PROMPT = """You are EcoReason AI, a decision-support assistant for gas-turbine NOx emission monitoring.
You receive an EVIDENCE PACKAGE (JSON) produced by a validated machine-learning model.
Write a short advisory for the control-room operator.

STRICT RULES
1. Use ONLY numbers that appear in the evidence package. Copy them exactly as given. Never estimate, convert or invent values.
2. The contributors are PREDICTIVE associations from the model (TreeSHAP). Call them "predictive contributors".
   Never say a variable caused, led to, or is responsible for the NOx level.
3. Do not instruct anyone to change equipment or set-points. Use only verbs such as review, monitor, verify, check, confirm.
4. Mention only variables that appear in the evidence package. Contributors with category "ambient"
   (weather) cannot be adjusted: present them as context, and suggest reviewing only "operational" variables.
5. State the risk level exactly as given in risk.level.
6. If data_quality.status is WARNING, say the prediction is less reliable and why.
7. If ammonia_estimate is present, you may report nh3_mg_per_m3 and nox_removal_needed exactly as given,
   described as an INDICATIVE stoichiometric requirement. Never phrase it as a dosing command.
8. The operator makes the final decision. Be concise: at most 140 words in total.

Return ONLY a JSON object, no markdown, with these string fields:
{"summary": "...", "explanation": "...", "advisory": "...", "confidence_note": "..."}"""


def _fmt(v: float, nd: int = 2) -> str:
    return f"{v:.{nd}f}".rstrip("0").rstrip(".") if isinstance(v, float) else str(v)


def template_advisory(ev: EvidencePackage) -> dict[str, str]:
    p, r, x = ev.prediction, ev.risk, ev.xai
    unit = p["unit"]
    if p["corrected"] is None:
        return {
            "summary": f"No NOₓ prediction for {ev.step_id}: input data invalid.",
            "explanation": "; ".join(ev.data_quality["flags"]) or "Invalid input.",
            "advisory": "Verify the data feed and rely on the CEMS reading for this hour.",
            "confidence_note": "No model output available for this hour.",
        }
    summary = (f"Predicted NOₓ for {ev.step_id}: {_fmt(p['corrected'])} {unit} "
               f"(model {_fmt(p['raw'])} {unit}, ME correction {p['me_correction']:+.2f}). "
               f"Risk level: {r['level']}.")
    parts = []
    for d in x["local_top"]:
        verb = "raises" if d["contribution"] > 0 else "lowers"
        parts.append(f"{d['feature']} ({d['description']}, {_fmt(d['value'])} {d['unit']}) "
                     f"{verb} the prediction by {_fmt(abs(d['contribution']))} {unit}")
    explanation = ("Largest predictive contributors this hour: " + "; ".join(parts) + ". "
                   "These are associations learned from historical data, not confirmed physical causes.")
    if r["trend_slope_per_hour"] is not None:
        explanation += (f" Trend of the corrected prediction: {r['trend']} "
                        f"({r['trend_slope_per_hour']:+.2f} {unit} per hour).")
    op = [d["feature"] for d in x["local_top"] if d.get("category") == "operational"][:2]
    amb = [d["feature"] for d in x["local_top"] if d.get("category") == "ambient"]
    review = (f"review the current operating condition of {' and '.join(op)}" if op
              else "review the overall turbine operating condition")
    context = (f" Ambient conditions ({', '.join(amb)}) are among the contributors; they are context, "
               f"not adjustable settings." if amb else "")
    if r["level"] == "HIGH":
        advisory = (f"HIGH predicted NOₓ: {review} and confirm against the CEMS reading when it arrives. "
                    f"Follow the plant's standard NOₓ exceedance procedure; the final decision rests with "
                    f"the operator.{context}")
    elif r["level"] == "MEDIUM" and r["escalated"]:
        advisory = (f"Early warning: the prediction is rising towards the MEDIUM threshold "
                    f"({_fmt(r['thresholds']['MEDIUM'])} {unit}). Monitor the next readings closely and "
                    f"{review}.{context}")
    elif r["level"] == "MEDIUM":
        advisory = (f"Monitor the next readings closely and {review}. No immediate action is indicated by "
                    f"the model alone.{context}")
    else:
        advisory = "No action indicated. Continue normal monitoring."
    a = ev.ammonia
    if a:
        if a["nox_removal_needed"] > 0:
            advisory += (f" Indicative NH₃ requirement to bring NOₓ to {_fmt(a['target_nox'])} {unit}: "
                         f"{_fmt(a['nh3_mg_per_m3'])} mg NH₃ per m³ of flue gas "
                         f"(removal of {_fmt(a['nox_removal_needed'])} {unit}, {_fmt(a['removal_efficiency_pct'], 1)}%)")
            advisory += (f", about {_fmt(a['nh3_kg_per_h'])} kg/h." if a.get("nh3_kg_per_h") is not None else ".")
            advisory += " This is a stoichiometric estimate; actual dosing is decided by the SCR control system and the operator."
        else:
            advisory += f" Predicted NOₓ is below the {_fmt(a['target_nox'])} {unit} target, so no NH₃ is indicated."
    notes = []
    if ev.data_quality["status"] == "WARNING":
        notes.append("Prediction less reliable: " + "; ".join(ev.data_quality["flags"]))
    if p["residuals_available"] < p["me_window_hours"]:
        notes.append(f"ME correction uses only {p['residuals_available']} past CEMS readings.")
    notes.append("Advisory generated from model evidence; it is not a control instruction.")
    return {"summary": summary, "explanation": explanation, "advisory": advisory,
            "confidence_note": " ".join(notes)}


def _parse_json(text: str) -> dict[str, Any]:
    text = re.sub(r"^```(?:json)?|```$", "", text.strip(), flags=re.M).strip()
    m = re.search(r"\{.*\}", text, re.S)
    if not m:
        raise ValueError("LLM did not return JSON")
    return json.loads(m.group(0))


class ReasoningAgent:
    def __init__(self, cfg: dict, llm_fn: Callable[[str, str], str] | None = None):
        self.cfg = cfg["llm"]
        self.backend = self.cfg["backend"]
        self.call_on = set(self.cfg.get("call_on", ["MEDIUM", "HIGH"]))
        self._llm_fn = llm_fn               # injectable for tests
        self.n_calls = 0

    # -- backends ------------------------------------------------------------------------
    def _call_anthropic(self, system: str, user: str) -> str:
        c = self.cfg["anthropic"]
        key = os.environ.get(c["api_key_env"])
        if not key:
            raise RuntimeError(f"Environment variable {c['api_key_env']} is not set")
        r = requests.post("https://api.anthropic.com/v1/messages", timeout=self.cfg["timeout_s"],
                          headers={"x-api-key": key, "anthropic-version": "2023-06-01",
                                   "content-type": "application/json"},
                          json={"model": c["model"], "max_tokens": c["max_tokens"],
                                "temperature": self.cfg["temperature"], "system": system,
                                "messages": [{"role": "user", "content": user}]})
        r.raise_for_status()
        return "".join(b.get("text", "") for b in r.json()["content"] if b.get("type") == "text")

    def _call_ollama(self, system: str, user: str) -> str:
        c = self.cfg["ollama"]
        r = requests.post(c["url"], timeout=self.cfg["timeout_s"],
                          json={"model": c["model"], "stream": False, "format": "json",
                                "options": {"temperature": self.cfg["temperature"]},
                                "messages": [{"role": "system", "content": system},
                                             {"role": "user", "content": user}]})
        r.raise_for_status()
        return r.json()["message"]["content"]

    def _llm(self, system: str, user: str) -> str:
        if self._llm_fn:
            return self._llm_fn(system, user)
        if self.backend == "anthropic":
            return self._call_anthropic(system, user)
        if self.backend == "ollama":
            return self._call_ollama(system, user)
        raise ValueError(f"Unknown LLM backend '{self.backend}'")

    # -- main -------------------------------------------------------------------------------
    def advise(self, ev: EvidencePackage) -> dict[str, Any]:
        t0 = time.perf_counter()
        use_llm = (self.backend != "template" or self._llm_fn) and ev.risk["level"] in self.call_on
        out: dict[str, Any] = {"source": "template", "llm_error": None, "llm_raw": None,
                               "llm_violations": []}
        if use_llm:
            self.n_calls += 1
            user = ("EVIDENCE PACKAGE:\n" + json.dumps(ev.llm_view(), ensure_ascii=False, indent=1))
            try:
                raw = self._llm(SYSTEM_PROMPT, user)
                out["llm_raw"] = raw
                adv = _parse_json(raw)
                check = guardrails.validate(adv, ev.to_dict())
                if check["passed"]:
                    out.update(source="llm", advisory=adv, validation=check)
                else:
                    out["llm_violations"] = check["violations"]
            except Exception as e:  # network error, bad JSON, missing key ...
                out["llm_error"] = f"{type(e).__name__}: {e}"
            if out["source"] != "llm":
                out["source"] = "template_fallback"
        if "advisory" not in out:
            adv = template_advisory(ev)
            out["advisory"] = adv
            out["validation"] = guardrails.validate(adv, ev.to_dict())
        out["latency_s"] = time.perf_counter() - t0
        return out
