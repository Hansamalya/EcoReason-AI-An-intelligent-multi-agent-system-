"""Agent 1 — Data Agent.

Receives sequential plant observations, validates them and maintains the
current plant state. It never sees the NOx value of the current hour
(in a plant, the CEMS reading arrives after the prediction is made).
"""
from collections import deque
from typing import Iterator

import numpy as np
import pandas as pd

from ..evidence import PlantState


class DataAgent:
    def __init__(self, features: list[str], feature_ranges: dict, range_margin: float = 0.10,
                 history_hours: int = 24):
        self.features = features
        self.margin = range_margin
        self.bounds = {}
        for f in features:
            lo, hi = feature_ranges[f]["min"], feature_ranges[f]["max"]
            span = hi - lo
            self.bounds[f] = (lo, hi, lo - range_margin * span, hi + range_margin * span)
        self.history: deque = deque(maxlen=history_hours)

    # -- stream -----------------------------------------------------------------------
    @staticmethod
    def stream(df: pd.DataFrame, target: str) -> Iterator[tuple[dict, float]]:
        """Replay a DataFrame row by row: yields (observation_without_target, cems_value)."""
        for rec in df.to_dict(orient="records"):
            cems = rec.pop(target)
            yield rec, cems

    # -- validate -----------------------------------------------------------------------
    def observe(self, rec: dict) -> PlantState:
        values, flags = {}, []
        quality = "OK"
        for f in self.features:
            v = rec.get(f)
            if v is None or (isinstance(v, float) and np.isnan(v)):
                flags.append(f"{f}: missing value")
                quality = "INVALID"
                continue
            v = float(v)
            values[f] = v
            lo, hi, hard_lo, hard_hi = self.bounds[f]
            if v < hard_lo or v > hard_hi:
                flags.append(f"{f}={v:.2f} is far outside the training range [{lo:.2f}, {hi:.2f}]")
                quality = "WARNING" if quality == "OK" else quality
            elif v < lo or v > hi:
                flags.append(f"{f}={v:.2f} is slightly outside the training range [{lo:.2f}, {hi:.2f}]")
                quality = "WARNING" if quality == "OK" else quality

        if quality != "INVALID" and self.history:
            prev = self.history[-1]
            if all(prev.get(f) == values.get(f) for f in self.features):
                flags.append("All inputs identical to previous hour (possible frozen sensor feed)")
                quality = "WARNING" if quality == "OK" else quality

        if quality != "INVALID":
            self.history.append(values)

        return PlantState(step_id=str(rec.get("STEP_ID", "")), year=int(rec.get("YEAR", 0)),
                          hour_idx=int(rec.get("HOUR_IDX", 0)), values=values, quality=quality,
                          flags=flags, history_len=len(self.history))
