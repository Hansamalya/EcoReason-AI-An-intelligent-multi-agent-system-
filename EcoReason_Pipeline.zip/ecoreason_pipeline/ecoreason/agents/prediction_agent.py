"""Agent 2 — Prediction Agent.

Takes the plant state and
  1. predicts NOx with the validated ML model,
  2. applies the rolling Mean Error (ME) correction from past CEMS readings,
  3. assigns a risk level (threshold + trend rules),
  4. produces XAI evidence (local TreeSHAP contributions + global ranking),
and packs everything into an EvidencePackage.

All numbers the LLM will ever see are created here — the LLM never computes them.
"""
import json
from collections import deque
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import xgboost as xgb

from ..evidence import EvidencePackage, PlantState

LEVELS = ["LOW", "MEDIUM", "HIGH"]


class PredictionAgent:
    def __init__(self, artifacts_dir: Path, cfg: dict):
        artifacts_dir = Path(artifacts_dir)
        self.model = joblib.load(artifacts_dir / "model.joblib")
        self.booster = self.model.get_booster()
        self.scaler = joblib.load(artifacts_dir / "scaler.joblib")
        self.meta = json.loads((artifacts_dir / "meta.json").read_text(encoding="utf-8"))
        self.features = self.meta["features"]
        self.target = self.meta["target"]
        self.units = cfg["units"]
        self.desc = cfg.get("descriptions", {})
        self.ambient = set(cfg.get("ambient_features", []))
        self.top_k = cfg["xai"]["top_k"]
        self.rc = cfg["risk"]
        self.thr = self.meta["risk_thresholds"]
        self.me_window = cfg["me_correction"]["window_hours"]
        self.nh3 = cfg.get("ammonia", {"enabled": False})
        self.residuals: deque = deque(maxlen=self.me_window)
        self.recent: deque = deque(maxlen=max(self.rc["trend_window_hours"], 6))
        self._pending: dict[str, float] = {}      # step_id -> raw prediction awaiting CEMS value
        self._cems_hist: deque = deque(maxlen=3)
        self.suspect_cems = 0                     # CEMS readings rejected from the ME buffer

    # ---------------------------------------------------------------------------------
    def _level(self, value: float) -> str:
        if value >= self.thr["HIGH"]:
            return "HIGH"
        if value >= self.thr["MEDIUM"]:
            return "MEDIUM"
        return "LOW"

    def _local_xai(self, x_scaled: np.ndarray, state: PlantState) -> tuple[list[dict], float]:
        contrib = self.booster.predict(xgb.DMatrix(x_scaled, feature_names=None), pred_contribs=True)[0]
        base = float(contrib[-1])
        items = []
        for f, c in zip(self.features, contrib[:-1]):
            items.append({"feature": f, "description": self.desc.get(f, f),
                          "category": "ambient" if f in self.ambient else "operational",
                          "value": round(state.values[f], 2), "unit": self.units.get(f, ""),
                          "contribution": round(float(c), 2),
                          "direction": "raises the prediction" if c > 0 else "lowers the prediction"})
        items.sort(key=lambda d: -abs(d["contribution"]))
        return items[: self.top_k], base

    def ammonia_estimate(self, nox: float) -> dict | None:
        """Stoichiometric NH3 needed to bring NOx down to the target (standard SCR: 4NO + 4NH3 + O2 → 4N2 + 6H2O).

        NH3 [mg/m³] = (NOx − target) [mg/m³ as NO2] × M(NH3)/M(NO2) × NSR
        """
        c = self.nh3
        if not c or not c.get("enabled"):
            return None
        target = float(c["target_nox"])
        removal = max(0.0, nox - target)
        ratio = c["nh3_molar_mass"] / c["nox_molar_mass"]
        nh3 = removal * ratio * c["nsr"]
        out = {"target_nox": target, "unit": "mg/m³", "nox_removal_needed": round(removal, 2),
               "removal_efficiency_pct": round(100 * removal / nox, 1) if nox > 0 else 0.0,
               "nh3_mg_per_m3": round(nh3, 2), "nsr": c["nsr"],
               "mass_ratio_nh3_per_nox": round(ratio, 3),
               "basis": "stoichiometric estimate, NOx as NO2, 1 mol NH3 per mol NOx × NSR",
               "nh3_kg_per_h": None}
        if c.get("flue_gas_flow_nm3_per_h"):
            out["flue_gas_flow_nm3_per_h"] = c["flue_gas_flow_nm3_per_h"]
            out["nh3_kg_per_h"] = round(nh3 * c["flue_gas_flow_nm3_per_h"] / 1e6, 2)
        return out

    # ---------------------------------------------------------------------------------
    def assess(self, state: PlantState) -> EvidencePackage:
        unit = self.units.get(self.target, "")
        plant_state = {f: {"value": round(v, 2), "unit": self.units.get(f, ""),
                           "description": self.desc.get(f, f)} for f, v in state.values.items()}
        global_top = [{"feature": d["feature"], "rank": d["rank"]}
                      for d in self.meta["global_importance"][: self.top_k]]
        model_info = {"type": self.meta["model_type"], "train_years": self.meta["train_years"]}

        if state.quality == "INVALID":
            return EvidencePackage(
                step_id=state.step_id, plant_state=plant_state,
                data_quality={"status": state.quality, "flags": state.flags},
                prediction={"raw": None, "me_correction": None, "corrected": None, "unit": unit,
                            "me_window_hours": self.me_window, "residuals_available": len(self.residuals)},
                risk={"level": "UNKNOWN", "thresholds": self.thr, "trend_slope_per_hour": None,
                      "trend": "unknown", "escalated": False,
                      "rule": "No prediction: input data invalid"},
                xai={"local_top": [], "global_top": global_top, "base_value": None},
                recent_predictions=[round(v, 2) for v in self.recent], model=model_info)

        x = pd.DataFrame([state.values])[self.features]
        x_scaled = self.scaler.transform(x)
        raw = float(self.model.predict(x_scaled)[0])
        me = float(np.mean(self.residuals)) if self.residuals else 0.0
        corrected = raw + me
        self._pending[state.step_id] = raw
        self.recent.append(corrected)

        # --- risk rules ----------------------------------------------------------------
        level = self._level(corrected)
        w = self.rc["trend_window_hours"]
        slope = None
        trend = "insufficient history"
        if len(self.recent) >= w:
            ys = list(self.recent)[-w:]
            slope = float(np.polyfit(np.arange(w), ys, 1)[0])
            trend = ("rising fast" if slope >= self.rc["trend_alert_slope"]
                     else "rising" if slope > 0.5 else "falling" if slope < -0.5 else "stable")
        escalated = False
        rule = f"Corrected prediction compared with thresholds ({self.meta['risk_threshold_basis']})"
        if (level == "LOW" and slope is not None and slope >= self.rc["trend_alert_slope"]
                and corrected >= self.thr["MEDIUM"] - self.rc["early_warning_band"]):
            level, escalated = "MEDIUM", True
            rule = (f"Early warning: LOW escalated to MEDIUM because the prediction is rising "
                    f"≥ {self.rc['trend_alert_slope']} {unit}/h and is within "
                    f"{self.rc['early_warning_band']} {unit} of the MEDIUM threshold")

        local_top, base = self._local_xai(x_scaled, state)
        return EvidencePackage(
            step_id=state.step_id, plant_state=plant_state,
            data_quality={"status": state.quality, "flags": state.flags},
            prediction={"raw": round(raw, 2), "me_correction": round(me, 2),
                        "corrected": round(corrected, 2), "unit": unit,
                        "me_window_hours": self.me_window, "residuals_available": len(self.residuals)},
            risk={"level": level, "thresholds": self.thr,
                  "trend_slope_per_hour": None if slope is None else round(slope, 2),
                  "trend": trend, "escalated": escalated, "rule": rule},
            xai={"local_top": local_top, "global_top": global_top, "base_value": round(base, 2),
                 "method": "TreeSHAP contributions (mg/m³) relative to the model's average prediction"},
            recent_predictions=[round(v, 2) for v in self.recent],
            model=model_info, ammonia=self.ammonia_estimate(corrected))

    # ---------------------------------------------------------------------------------
    def receive_measurement(self, step_id: str, cems_value: float | None) -> str:
        """Called when the CEMS value for an hour arrives; updates the ME correction buffer."""
        raw = self._pending.pop(step_id, None)
        if cems_value is None or np.isnan(cems_value):
            return "missing"
        cems_value = float(cems_value)
        self._cems_hist.append(cems_value)
        # CEMS plausibility: 3 consecutive steps on an exact straight line (constant or linearly
        # gap-filled readings) are unlikely for a real hourly average -> do not learn bias from them.
        if len(self._cems_hist) == 3:
            a, b, c = self._cems_hist
            if abs((c - b) - (b - a)) < 1e-3:
                self.suspect_cems += 1
                return "suspect_interpolated"
        if raw is None:
            return "no_prediction"
        self.residuals.append(cems_value - raw)
        return "ok"
