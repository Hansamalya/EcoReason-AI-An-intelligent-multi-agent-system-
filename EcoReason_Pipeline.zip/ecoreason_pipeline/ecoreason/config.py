"""Configuration loading and shared data helpers."""
from pathlib import Path

import numpy as np
import pandas as pd
import yaml

ROOT = Path(__file__).resolve().parents[1]


def load_config(path: str | Path = ROOT / "config.yaml") -> dict:
    with open(path, encoding="utf-8") as fh:
        cfg = yaml.safe_load(fh)
    cfg["_root"] = str(Path(path).resolve().parent)
    return cfg


def resolve(cfg: dict, rel: str) -> Path:
    """Resolve a path from the config relative to the project root."""
    p = Path(rel)
    return p if p.is_absolute() else Path(cfg["_root"]) / p


def load_data(cfg: dict, years: list[int] | None = None) -> pd.DataFrame:
    """Load the yearly CSV files, keeping chronological order.

    Adds YEAR, HOUR_IDX (position within the year) and a readable STEP_ID.
    """
    frames = []
    for year, rel in cfg["data"]["files"].items():
        year = int(year)
        if years is not None and year not in years:
            continue
        d = pd.read_csv(resolve(cfg, rel))
        d["YEAR"] = year
        d["HOUR_IDX"] = np.arange(len(d))
        frames.append(d)
    df = pd.concat(frames, ignore_index=True)
    df["STEP_ID"] = df["YEAR"].astype(str) + "-h" + df["HOUR_IDX"].astype(str).str.zfill(4)
    return df
