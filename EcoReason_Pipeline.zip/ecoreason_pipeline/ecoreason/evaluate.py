"""Evaluation of a replay run (slide 13: Experimental Design & Evaluation).

A. Prediction quality      MAE, RMSE, R², ME — raw vs ME-corrected vs persistence baseline
B. Risk / alert quality    confusion matrix, precision/recall/F1 for alerts, early-warning capture
C. Agentic system          end-to-end latency per stage, throughput
D. Advisory safety         guardrail pass rate, LLM fallbacks, violation types
"""
import json
from collections import Counter
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.metrics import confusion_matrix, mean_absolute_error, mean_squared_error, r2_score

LEVELS = ["LOW", "MEDIUM", "HIGH"]


def _m(y, p):
    return {"MAE": float(mean_absolute_error(y, p)), "RMSE": float(np.sqrt(mean_squared_error(y, p))),
            "R2": float(r2_score(y, p)), "ME": float(np.mean(y - p))}


def _prf(actual: np.ndarray, pred: np.ndarray) -> dict:
    tp = int((actual & pred).sum()); fp = int((~actual & pred).sum()); fn = int((actual & ~pred).sum())
    prec = tp / (tp + fp) if tp + fp else 0.0
    rec = tp / (tp + fn) if tp + fn else 0.0
    f1 = 2 * prec * rec / (prec + rec) if prec + rec else 0.0
    return {"TP": tp, "FP": fp, "FN": fn, "precision": prec, "recall": rec, "F1": f1}


def evaluate(run_dir: Path) -> dict:
    run_dir = Path(run_dir)
    h = pd.read_csv(run_dir / "hourly_results.csv")
    info = json.loads((run_dir / "run_info.json").read_text(encoding="utf-8"))
    thr = info["risk_thresholds"]
    valid = h.dropna(subset=["pred_corrected"]).copy()
    y = valid["cems_nox"].values

    # ---- A. prediction ------------------------------------------------------------------
    persist = pd.Series(h["cems_nox"].values).shift(1).bfill().values[valid.index]
    A = {"raw_model": _m(y, valid["pred_raw"].values),
         "me_corrected": _m(y, valid["pred_corrected"].values),
         "persistence_baseline": _m(y, persist)}

    # ---- B. risk --------------------------------------------------------------------------
    actual_lvl = np.where(y >= thr["HIGH"], "HIGH", np.where(y >= thr["MEDIUM"], "MEDIUM", "LOW"))
    pred_lvl = valid["risk_level"].values
    cm = confusion_matrix(actual_lvl, pred_lvl, labels=LEVELS)
    alert_any = _prf(actual_lvl != "LOW", pred_lvl != "LOW")
    alert_high = _prf(actual_lvl == "HIGH", pred_lvl == "HIGH")
    hours = len(valid)
    false_alarms_per_day = alert_any["FP"] / (hours / 24) if hours else 0.0

    # early warning: for each episode of actual HIGH, was an alert (MEDIUM+) raised at onset or 1–3 h before?
    is_high = actual_lvl == "HIGH"
    alert = pred_lvl != "LOW"
    onsets = [i for i in range(len(is_high)) if is_high[i] and (i == 0 or not is_high[i - 1])]
    at_onset = sum(alert[i] for i in onsets)
    before = sum(any(alert[max(0, i - 3): i]) for i in onsets)
    B = {"actual_level_counts": dict(Counter(actual_lvl)), "predicted_level_counts": dict(Counter(pred_lvl)),
         "confusion_matrix": {"labels": LEVELS, "rows_actual_cols_predicted": cm.tolist()},
         "alert_MEDIUM_or_HIGH": alert_any, "alert_HIGH": alert_high,
         "false_alarms_per_day": false_alarms_per_day,
         "early_warning": {"high_episodes": len(onsets),
                           "alert_at_onset_pct": 100 * at_onset / len(onsets) if onsets else None,
                           "alert_1to3h_before_pct": 100 * before / len(onsets) if onsets else None},
         "escalations": int(valid["escalated"].sum())}

    # ---- C. latency -----------------------------------------------------------------------
    C = {k: {"mean_ms": float(h[k].mean()), "p95_ms": float(h[k].quantile(0.95)), "max_ms": float(h[k].max())}
         for k in ["data_ms", "predict_ms", "reason_ms", "total_ms"]}
    C["throughput_obs_per_s"] = float(1000 / h["total_ms"].mean())

    # ---- D. safety ------------------------------------------------------------------------
    viol = Counter()
    for s in h["llm_violation_types"].fillna(""):
        for t in filter(None, str(s).split(";")):
            viol[t] += 1
    llm_rows = h[h["advisory_source"].isin(["llm", "template_fallback"])]
    D = {"advisories": len(h), "final_guardrail_pass_rate": float(h["guardrail_passed"].mean()),
         "source_counts": dict(Counter(h["advisory_source"])), "llm_calls": int(len(llm_rows)),
         "llm_accepted_rate": float((llm_rows["advisory_source"] == "llm").mean()) if len(llm_rows) else None,
         "llm_errors": int(h["llm_error"].notna().sum()), "llm_violation_counts": dict(viol),
         "data_quality_counts": dict(Counter(h["data_quality"])),
         "cems_status_counts": dict(Counter(h["cems_status"]))}

    # ---- E. NOx emitted & NH3 requirement ------------------------------------------------
    E = {"nox_actual": {"mean": float(y.mean()), "median": float(np.median(y)), "p95": float(np.percentile(y, 95)),
                        "max": float(y.max()),
                        "pct_hours_medium_or_high": float(100 * (y >= thr["MEDIUM"]).mean()),
                        "pct_hours_high": float(100 * (y >= thr["HIGH"]).mean())},
         "by_year": {int(k): float(v) for k, v in valid.groupby("year")["cems_nox"].mean().items()}}
    a = info.get("ammonia") or {}
    if a.get("enabled") and "nh3_mg_per_m3" in valid:
        ratio = a["nh3_molar_mass"] / a["nox_molar_mass"] * a["nsr"]
        nh3_true = np.maximum(0, y - a["target_nox"]) * ratio          # what the actual CEMS NOx would need
        nh3_pred = valid["nh3_mg_per_m3"].values.astype(float)          # what the pipeline estimated in advance
        E["ammonia"] = {"target_nox": a["target_nox"], "nsr": a["nsr"],
                        "pct_hours_above_target": float(100 * (y > a["target_nox"]).mean()),
                        "nh3_mean_estimated": float(nh3_pred.mean()), "nh3_mean_required_actual": float(nh3_true.mean()),
                        "nh3_p95_required_actual": float(np.percentile(nh3_true, 95)),
                        "nh3_MAE": float(np.mean(np.abs(nh3_pred - nh3_true))),
                        "nh3_bias_estimated_minus_actual": float(np.mean(nh3_pred - nh3_true)),
                        "mean_removal_efficiency_pct_needed": float(100 * np.mean(np.maximum(0, y - a["target_nox"]) / y))}

    res = {"run": info, "A_prediction": A, "B_risk": B, "C_latency": C, "D_safety": D, "E_emission_ammonia": E}
    (run_dir / "metrics.json").write_text(json.dumps(res, indent=2, default=float), encoding="utf-8")
    _figure(valid, thr, run_dir)
    _report(res, run_dir)
    return res


def _figure(v: pd.DataFrame, thr: dict, run_dir: Path) -> None:
    v = v.reset_index(drop=True)
    # show the 10-day window containing the most actual HIGH hours
    dens = (v["cems_nox"] >= thr["HIGH"]).astype(int).rolling(240, min_periods=1).sum()
    end = int(dens.idxmax()) + 1
    s = slice(max(0, end - 240), end)
    w = v.iloc[s]
    x = np.arange(len(w))
    fig, ax = plt.subplots(figsize=(13, 4.5))
    ax.plot(x, w["cems_nox"], color="k", lw=1.3, label="CEMS NOₓ (actual)")
    ax.plot(x, w["pred_corrected"], color="#2E75B6", lw=1.1, label="Prediction + ME correction")
    ax.axhline(thr["MEDIUM"], color="#ED7D31", ls="--", lw=1, label=f"MEDIUM ≥ {thr['MEDIUM']}")
    ax.axhline(thr["HIGH"], color="#C00000", ls="--", lw=1, label=f"HIGH ≥ {thr['HIGH']}")
    for lvl, c in (("MEDIUM", "#ED7D31"), ("HIGH", "#C00000")):
        m = (w["risk_level"] == lvl).values
        ax.scatter(x[m], w["pred_corrected"].values[m], color=c, s=14, zorder=3)
    ax.set_xticks(x[::24]); ax.set_xticklabels(w["step_id"].values[::24], rotation=30, fontsize=8)
    ax.set_ylabel("NOₓ (mg/m³)"); ax.set_title("EcoReason AI replay: predictions, risk alerts and CEMS values")
    ax.legend(fontsize=8, loc="upper left"); ax.grid(alpha=0.3)
    fig.tight_layout(); fig.savefig(run_dir / "replay_alerts.png", dpi=200); plt.close(fig)


def _report(r: dict, run_dir: Path) -> None:
    A, B, C, D, E = r["A_prediction"], r["B_risk"], r["C_latency"], r["D_safety"], r["E_emission_ammonia"]
    L = [f"# EcoReason AI — replay evaluation", "",
         f"Backend: **{r['run']['backend']}** · observations: **{r['run']['observations']:,}** · "
         f"ME window: {r['run']['me_window_hours']} h · thresholds: MEDIUM ≥ {r['run']['risk_thresholds']['MEDIUM']}, "
         f"HIGH ≥ {r['run']['risk_thresholds']['HIGH']} mg/m³ ({r['run']['risk_threshold_basis']})", "",
         "## A. Prediction quality", "", "| Method | MAE | RMSE | R² | ME |", "|---|---|---|---|---|"]
    for k, name in (("raw_model", "Model (no correction)"), ("me_corrected", "Model + ME correction"),
                    ("persistence_baseline", "Persistence baseline")):
        m = A[k]; L.append(f"| {name} | {m['MAE']:.2f} | {m['RMSE']:.2f} | {m['R2']:.3f} | {m['ME']:.2f} |")
    cm = B["confusion_matrix"]["rows_actual_cols_predicted"]
    L += ["", "## B. Risk alerts", "", "Confusion matrix (rows = actual level from CEMS, columns = predicted level):", "",
          "| | pred LOW | pred MEDIUM | pred HIGH |", "|---|---|---|---|"]
    for lab, row in zip(LEVELS, cm):
        L.append(f"| **actual {lab}** | {row[0]} | {row[1]} | {row[2]} |")
    for k, name in (("alert_MEDIUM_or_HIGH", "Any alert (MEDIUM or HIGH)"), ("alert_HIGH", "HIGH alert")):
        a = B[k]
        L.append(f"\n{name}: precision {a['precision']:.2f}, recall {a['recall']:.2f}, F1 {a['F1']:.2f} "
                 f"(TP {a['TP']}, FP {a['FP']}, FN {a['FN']})")
    ew = B["early_warning"]
    L += [f"\nFalse alarms per day: {B['false_alarms_per_day']:.2f} · trend escalations: {B['escalations']}",
          f"\nEarly warning: {ew['high_episodes']} actual HIGH episodes; alert raised at onset in "
          f"{(ew['alert_at_onset_pct'] or 0):.1f}% and 1–3 h before onset in {(ew['alert_1to3h_before_pct'] or 0):.1f}%.",
          "", "## C. End-to-end latency per observation", "", "| Stage | mean (ms) | p95 (ms) | max (ms) |", "|---|---|---|---|"]
    for k in ["data_ms", "predict_ms", "reason_ms", "total_ms"]:
        L.append(f"| {k.replace('_ms', '')} | {C[k]['mean_ms']:.2f} | {C[k]['p95_ms']:.2f} | {C[k]['max_ms']:.2f} |")
    L += [f"\nThroughput: {C['throughput_obs_per_s']:.1f} observations/s", "", "## D. Advisory safety", "",
          f"- Final guardrail pass rate: {100 * D['final_guardrail_pass_rate']:.2f}%",
          f"- Advisory sources: {D['source_counts']}",
          f"- LLM calls: {D['llm_calls']}; accepted after guardrails: "
          + (f"{100 * D['llm_accepted_rate']:.1f}%" if D["llm_accepted_rate"] is not None else "n/a"),
          f"- LLM errors: {D['llm_errors']}; violation types: {D['llm_violation_counts'] or 'none'}",
          f"- Input data quality (Data Agent): {D['data_quality_counts']}",
          f"- CEMS feedback status (suspect = straight-line / gap-filled readings excluded from ME): "
          f"{D['cems_status_counts']}", "",
          "## E. NOₓ emitted and indicative NH₃ requirement", "",
          f"- Actual NOₓ (CEMS): mean {E['nox_actual']['mean']:.2f}, median {E['nox_actual']['median']:.2f}, "
          f"P95 {E['nox_actual']['p95']:.2f}, max {E['nox_actual']['max']:.2f} mg/m³",
          f"- Hours at MEDIUM or HIGH: {E['nox_actual']['pct_hours_medium_or_high']:.1f}% · HIGH: {E['nox_actual']['pct_hours_high']:.1f}%",
          f"- Mean NOₓ by year: " + ", ".join(f"{k}: {v:.2f}" for k, v in E["by_year"].items())]
    if "ammonia" in E:
        m = E["ammonia"]
        L += [f"- Target after SCR: {m['target_nox']} mg/m³ (NSR {m['nsr']}); hours above target: {m['pct_hours_above_target']:.1f}%",
              f"- NH₃ required from actual NOₓ: mean {m['nh3_mean_required_actual']:.2f}, P95 {m['nh3_p95_required_actual']:.2f} mg/m³; "
              f"mean removal efficiency needed {m['mean_removal_efficiency_pct_needed']:.1f}%",
              f"- NH₃ estimated in advance by the pipeline: mean {m['nh3_mean_estimated']:.2f} mg/m³; "
              f"MAE {m['nh3_MAE']:.2f}, bias {m['nh3_bias_estimated_minus_actual']:+.2f} mg/m³"]
    L += ["", "![replay](replay_alerts.png)"]
    (run_dir / "report.md").write_text("\n".join(L), encoding="utf-8")
