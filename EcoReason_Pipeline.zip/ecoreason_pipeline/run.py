"""EcoReason AI — command-line entry point.

  python run.py train                         # Stage 0: train model, write artifacts/
  python run.py demo                          # one alert hour: evidence package + advisory
  python run.py replay --limit 500            # replay 2014–2015 hour by hour through the agents
  python run.py replay --llm anthropic        # use Claude for MEDIUM/HIGH advisories
  python run.py replay --llm ollama           # use a free local model via Ollama
  python run.py evaluate                      # metrics + report for the latest run
  python run.py test                          # guardrail red-team tests
"""
import argparse
import json
import sys
from pathlib import Path

from ecoreason.config import load_config, resolve


def ensure_artifacts(cfg):
    if not (resolve(cfg, cfg["artifacts_dir"]) / "meta.json").exists():
        print("No artifacts found — training first.")
        from ecoreason.train import train
        train(cfg)


def latest_run(cfg) -> Path:
    runs = sorted(resolve(cfg, cfg["output_dir"]).glob("run_*"))
    if not runs:
        sys.exit("No runs found. Run `python run.py replay` first.")
    return runs[-1]


def main():
    ap = argparse.ArgumentParser(description="EcoReason AI pipeline")
    ap.add_argument("command", choices=["train", "replay", "evaluate", "demo", "test"])
    ap.add_argument("--config", default=str(Path(__file__).parent / "config.yaml"))
    ap.add_argument("--llm", choices=["template", "anthropic", "ollama"], help="override llm.backend")
    ap.add_argument("--limit", type=int, help="number of hours to replay")
    ap.add_argument("--start", type=int, default=0, help="start index in the replay stream")
    ap.add_argument("--run", help="run directory to evaluate (default: latest)")
    ap.add_argument("--verbose", action="store_true", help="print every MEDIUM/HIGH advisory")
    a = ap.parse_args()
    cfg = load_config(a.config)

    if a.command == "train":
        from ecoreason.train import train
        train(cfg)

    elif a.command == "replay":
        ensure_artifacts(cfg)
        from ecoreason.evaluate import evaluate
        from ecoreason.pipeline import EcoReasonPipeline
        run_dir = EcoReasonPipeline(cfg, llm_backend=a.llm).run(limit=a.limit, start=a.start, verbose=a.verbose)
        evaluate(run_dir)
        print((run_dir / "report.md").read_text(encoding="utf-8").split("![replay]")[0])

    elif a.command == "evaluate":
        from ecoreason.evaluate import evaluate
        run_dir = Path(a.run) if a.run else latest_run(cfg)
        evaluate(run_dir)
        print((run_dir / "report.md").read_text(encoding="utf-8").split("![replay]")[0])

    elif a.command == "demo":
        ensure_artifacts(cfg)
        from ecoreason.config import load_data
        from ecoreason.pipeline import EcoReasonPipeline
        pipe = EcoReasonPipeline(cfg, llm_backend=a.llm)
        df = load_data(cfg, [int(y) for y in cfg["data"]["replay_years"]])
        target = cfg["data"]["target"]
        # warm up the ME buffer, then stop at the first HIGH-risk hour
        from ecoreason.agents.data_agent import DataAgent
        for obs, cems in DataAgent.stream(df.iloc[a.start:], target):
            rec = pipe.step(obs, cems)
            if rec["evidence"].risk["level"] == "HIGH" and rec["evidence"].prediction["residuals_available"] >= 24:
                break
        ev, adv = rec["evidence"], rec["advisory"]
        print("=" * 80, "\nEVIDENCE PACKAGE (sent to the Reasoning Agent)\n" + "=" * 80)
        print(json.dumps(ev.llm_view(), indent=2, ensure_ascii=False))
        print("=" * 80, f"\nADVISORY  [source: {adv['source']}]\n" + "=" * 80)
        for k, v in adv["advisory"].items():
            print(f"{k.upper():16}: {v}")
        print(f"\nGuardrails passed: {adv['validation']['passed']}   |   CEMS value that arrived afterwards: "
              f"{rec['cems']:.2f} mg/m³")
        if adv["llm_violations"] or adv["llm_error"]:
            print("LLM output rejected:", adv["llm_violations"] or adv["llm_error"])

    elif a.command == "test":
        import tests.test_guardrails as t
        t.run_all()


if __name__ == "__main__":
    main()
