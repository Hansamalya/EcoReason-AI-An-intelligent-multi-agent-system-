# EcoReason AI — replay evaluation

Backend: **template** · observations: **14,542** · ME window: 24 h · thresholds: MEDIUM ≥ 74.57, HIGH ≥ 82.13 mg/m³ (P75 / P90 of training-period NOX (2011–2013))

## A. Prediction quality

| Method | MAE | RMSE | R² | ME |
|---|---|---|---|---|
| Model (no correction) | 11.11 | 12.62 | -0.425 | -10.57 |
| Model + ME correction | 3.40 | 5.13 | 0.764 | -0.00 |
| Persistence baseline | 2.34 | 5.03 | 0.774 | 0.00 |

## B. Risk alerts

Confusion matrix (rows = actual level from CEMS, columns = predicted level):

| | pred LOW | pred MEDIUM | pred HIGH |
|---|---|---|---|
| **actual LOW** | 12930 | 306 | 70 |
| **actual MEDIUM** | 253 | 223 | 154 |
| **actual HIGH** | 80 | 89 | 437 |

Any alert (MEDIUM or HIGH): precision 0.71, recall 0.73, F1 0.72 (TP 903, FP 376, FN 333)

HIGH alert: precision 0.66, recall 0.72, F1 0.69 (TP 437, FP 224, FN 169)

False alarms per day: 0.62 · trend escalations: 112

Early warning: 199 actual HIGH episodes; alert raised at onset in 85.4% and 1–3 h before onset in 58.8%.

## C. End-to-end latency per observation

| Stage | mean (ms) | p95 (ms) | max (ms) |
|---|---|---|---|
| data | 0.02 | 0.02 | 0.14 |
| predict | 8.77 | 9.49 | 57.00 |
| reason | 0.47 | 0.65 | 4.18 |
| total | 9.26 | 10.03 | 61.19 |

Throughput: 108.0 observations/s

## D. Advisory safety

- Final guardrail pass rate: 100.00%
- Advisory sources: {'template': 14542}
- LLM calls: 0; accepted after guardrails: n/a
- LLM errors: 0; violation types: none
- Input data quality (Data Agent): {'OK': 14417, 'WARNING': 125}
- CEMS feedback status (suspect = straight-line / gap-filled readings excluded from ME): {'ok': 14496, 'suspect_interpolated': 46}

## E. NOₓ emitted and indicative NH₃ requirement

- Actual NOₓ (CEMS): mean 59.98, median 58.13, P95 80.58, max 119.68 mg/m³
- Hours at MEDIUM or HIGH: 8.5% · HIGH: 4.2%
- Mean NOₓ by year: 2014: 60.07, 2015: 59.89
- Target after SCR: 50.0 mg/m³ (NSR 1.0); hours above target: 86.9%
- NH₃ required from actual NOₓ: mean 3.83, P95 11.32 mg/m³; mean removal efficiency needed 15.2%
- NH₃ estimated in advance by the pipeline: mean 3.85 mg/m³; MAE 1.15, bias +0.02 mg/m³

![replay](replay_alerts.png)